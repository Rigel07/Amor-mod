package com.amorverdadero.love;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class LoveData extends SavedData {
    private static final String NAME = "amorverdadero_parejas";

    public final List<Couple> couples = new ArrayList<>();

    public static LoveData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(LoveData::load, LoveData::new, NAME);
    }

    public static LoveData load(CompoundTag tag) {
        LoveData data = new LoveData();
        ListTag list = tag.getList("couples", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            data.couples.add(Couple.load(list.getCompound(i)));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Couple c : couples) list.add(c.save());
        tag.put("couples", list);
        return tag;
    }

    public Couple getCouple(UUID id) {
        for (Couple c : couples) {
            if (c.has(id)) return c;
        }
        return null;
    }

    public void add(Couple c) {
        couples.add(c);
        setDirty();
    }

    public void remove(Couple c) {
        couples.remove(c);
        setDirty();
    }
}
