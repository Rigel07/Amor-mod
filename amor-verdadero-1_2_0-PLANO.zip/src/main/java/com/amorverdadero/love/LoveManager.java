package com.amorverdadero.love;

import com.amorverdadero.ModItems;
import com.amorverdadero.ModSounds;
import com.amorverdadero.item.ProposalRingItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class LoveManager {
    private LoveManager() {}

    private static final long PROPOSAL_TICKS = 2400L;     // 2 minutos para responder
    private static final long TP_COOLDOWN_TICKS = 600L;   // 30 s entre teletransportes
    private static final long REVIVE_COOLDOWN_TICKS = 12000L; // 10 min
    private static final long ROSE_COOLDOWN_TICKS = 6000L;
    private static final long PING_COOLDOWN_TICKS = 100L;
    private static final double NEAR_DISTANCE = 12.0D;

    private record Proposal(UUID proposer, String proposerName, int tier, long expires) {}

    private static final Map<UUID, Proposal> PENDING = new HashMap<>();
    private static final Map<UUID, Long> TP_COOLDOWN = new HashMap<>();
    private static final Map<UUID, Long> REVIVE_COOLDOWN = new HashMap<>();
    private static final Map<UUID, Long> ROSE_COOLDOWN = new HashMap<>();
    private static final Map<UUID, Long> PING_COOLDOWN = new HashMap<>();
    private static final Map<UUID, Long> DIVORCE_CONFIRM = new HashMap<>();

    // Ojo del Amor
    private static final long VIEW_TICKS = 600L;            // 30 s mirando
    private static final long VIEW_COOLDOWN_TICKS = 1200L;  // 60 s de espera
    private static final String VIEW_KEY = "amorverdadero_view";
    private record ViewSession(long endTick) {}
    private static final Map<UUID, ViewSession> VIEWS = new HashMap<>();
    private static final Map<UUID, Long> VIEW_COOLDOWN = new HashMap<>();

    private static final String[] PERKS = {
            "Regeneración cuando estáis cerca el uno del otro",
            "Velocidad cuando estáis cerca el uno del otro",
            "Absorción y «Amor que salva»: tu pareja te revive una vez cada 10 minutos",
            "Fuerza cuando estáis cerca el uno del otro",
            "Resistencia cuando estáis cerca el uno del otro"
    };

    // ------------------------------------------------------------------ utilidades

    private static long now(MinecraftServer server) {
        return server.overworld().getGameTime();
    }

    private static String name(ServerPlayer p) {
        return p.getName().getString();
    }

    private static void say(ServerPlayer p, String text, ChatFormatting color) {
        p.sendSystemMessage(Component.literal(text).withStyle(color));
    }

    private static void bar(ServerPlayer p, String text, ChatFormatting color) {
        p.displayClientMessage(Component.literal(text).withStyle(color), true);
    }

    private static void giveItem(ServerPlayer p, ItemStack stack) {
        if (!p.getInventory().add(stack)) {
            p.drop(stack, false);
        }
    }

    private static void sound(ServerPlayer p, SoundEvent ev, float vol, float pitch) {
        p.playNotifySound(ev, SoundSource.MASTER, vol, pitch);
    }

    private static void hearts(ServerPlayer p, int count) {
        p.serverLevel().sendParticles(ParticleTypes.HEART, p.getX(), p.getY() + 1.9, p.getZ(),
                count, 0.4, 0.3, 0.4, 0.02);
    }

    private static void title(ServerPlayer p, String title, ChatFormatting tc, String subtitle) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 100, 25));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title).withStyle(tc)));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(subtitle).withStyle(ChatFormatting.WHITE)));
    }

    private static Couple couple(ServerPlayer p) {
        return LoveData.get(p.server).getCouple(p.getUUID());
    }

    private static ServerPlayer onlinePartner(ServerPlayer p, Couple c) {
        return p.server.getPlayerList().getPlayer(c.other(p.getUUID()));
    }

    /** Devuelve la pareja si existe; si no, avisa al jugador. */
    private static Couple requireCouple(ServerPlayer p) {
        Couple c = couple(p);
        if (c == null) say(p, "Todavía no tienes pareja. Usa un anillo con otro jugador para declararte ♥", ChatFormatting.RED);
        return c;
    }

    /** Devuelve la pareja conectada si existe; si no, avisa al jugador. */
    private static ServerPlayer requirePartnerOnline(ServerPlayer p, Couple c) {
        ServerPlayer partner = onlinePartner(p, c);
        if (partner == null) say(p, c.otherName(p.getUUID()) + " no está conectado ahora mismo.", ChatFormatting.RED);
        return partner;
    }

    private static int tierOf(ItemStack s) {
        return s.getItem() instanceof ProposalRingItem r ? r.getTier() : -1;
    }

    private static int findBestRingTier(ServerPlayer p) {
        int best = -1;
        for (ItemStack s : p.getInventory().items) best = Math.max(best, tierOf(s));
        for (ItemStack s : p.getInventory().offhand) best = Math.max(best, tierOf(s));
        return best;
    }

    private static boolean consumeRing(ServerPlayer p, int tier) {
        if (p.getAbilities().instabuild) return true;
        for (ItemStack s : p.getInventory().items) {
            if (tierOf(s) == tier) { s.shrink(1); return true; }
        }
        for (ItemStack s : p.getInventory().offhand) {
            if (tierOf(s) == tier) { s.shrink(1); return true; }
        }
        return false;
    }

    private static int startPoints(int tier) {
        return tier == 3 ? 300 : tier == 2 ? 150 : tier == 1 ? 50 : 0;
    }

    // ------------------------------------------------------------------ declaración

    public static void proposeFromInventory(ServerPlayer p, ServerPlayer target) {
        int tier = findBestRingTier(p);
        if (tier < 0) {
            say(p, "Necesitas un anillo (oro, esmeralda, diamante o netherita) en tu inventario para declararte.", ChatFormatting.RED);
            return;
        }
        propose(p, target, tier);
    }

    public static void propose(ServerPlayer p, ServerPlayer target, int tier) {
        MinecraftServer server = p.server;
        LoveData data = LoveData.get(server);
        if (p == target) {
            say(p, "El amor propio es importante, pero aquí hace falta otra persona ♥", ChatFormatting.RED);
            return;
        }
        if (data.getCouple(p.getUUID()) != null) {
            say(p, "Ya compartes destino con alguien. Usa /amor divorcio si quieres empezar de nuevo.", ChatFormatting.RED);
            return;
        }
        if (data.getCouple(target.getUUID()) != null) {
            say(p, name(target) + " ya comparte destino con otra persona.", ChatFormatting.RED);
            return;
        }
        Proposal existing = PENDING.get(target.getUUID());
        if (existing != null && existing.expires() > now(server)) {
            say(p, name(target) + " ya tiene una declaración pendiente. Espera un poco.", ChatFormatting.RED);
            return;
        }
        PENDING.put(target.getUUID(), new Proposal(p.getUUID(), name(p), tier, now(server) + PROPOSAL_TICKS));

        say(p, "Le has declarado tu amor a " + name(target) + ". Ahora solo queda esperar su respuesta... ♥", ChatFormatting.LIGHT_PURPLE);
        hearts(p, 10);
        hearts(target, 10);

        title(target, "♥ Declaración de amor ♥", ChatFormatting.LIGHT_PURPLE, name(p) + " quiere compartir su destino contigo");
        sound(target, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.2F);
        target.sendSystemMessage(Component.literal("♥ " + name(p) + " te ofrece un anillo y quiere compartir su destino contigo.")
                .withStyle(ChatFormatting.LIGHT_PURPLE));

        MutableComponent yes = Component.literal("[ ♥ Aceptar ]").withStyle(Style.EMPTY
                .withColor(ChatFormatting.GREEN).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/amor aceptar"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Compartir destino para siempre"))));
        MutableComponent no = Component.literal("[ ✖ Rechazar ]").withStyle(Style.EMPTY
                .withColor(ChatFormatting.RED).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/amor rechazar"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Romperle el corazón..."))));
        target.sendSystemMessage(Component.literal("   ").append(yes).append(Component.literal("    ")).append(no));
        target.sendSystemMessage(Component.literal("(Tienes 2 minutos. También puedes usar /amor aceptar o /amor rechazar)")
                .withStyle(ChatFormatting.GRAY));
    }

    public static void accept(ServerPlayer target) {
        MinecraftServer server = target.server;
        Proposal pr = PENDING.get(target.getUUID());
        if (pr == null || pr.expires() < now(server)) {
            PENDING.remove(target.getUUID());
            say(target, "No tienes ninguna declaración pendiente.", ChatFormatting.RED);
            return;
        }
        PENDING.remove(target.getUUID());
        ServerPlayer p = server.getPlayerList().getPlayer(pr.proposer());
        if (p == null) {
            say(target, pr.proposerName() + " se ha desconectado. El momento ha pasado...", ChatFormatting.RED);
            return;
        }
        LoveData data = LoveData.get(server);
        if (data.getCouple(p.getUUID()) != null || data.getCouple(target.getUUID()) != null) {
            say(target, "Alguno de los dos ya comparte destino con otra persona.", ChatFormatting.RED);
            return;
        }
        if (!consumeRing(p, pr.tier())) {
            say(target, pr.proposerName() + " ya no tiene el anillo.", ChatFormatting.RED);
            say(p, "Ya no tienes el anillo de tu declaración.", ChatFormatting.RED);
            return;
        }

        Couple c = new Couple(p.getUUID(), target.getUUID(), name(p), name(target), now(server), startPoints(pr.tier()));
        data.add(c);

        giveItem(p, new ItemStack(ModItems.BOND_RING.get()));
        giveItem(target, new ItemStack(ModItems.BOND_RING.get()));

        for (ServerPlayer sp : new ServerPlayer[]{p, target}) {
            hearts(sp, 30);
            fireworks(sp);
            title(sp, "♥ ¡Destinos unidos! ♥", ChatFormatting.LIGHT_PURPLE, name(p) + " y " + name(target) + " comparten destino");
            sound(sp, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
            sound(sp, ModSounds.LOVE_MUSIC.get(), 1.0F, 1.0F);
            say(sp, "Habéis recibido una Alianza de Amor. Usa /amor para ver todo lo que podéis hacer juntos.", ChatFormatting.LIGHT_PURPLE);
        }
        server.getPlayerList().broadcastSystemMessage(
                Component.literal("♥ " + name(p) + " y " + name(target) + " ahora comparten destino ♥").withStyle(ChatFormatting.LIGHT_PURPLE), false);

        ServerLevel overworld = server.overworld();
        if (overworld.isRaining()) {
            overworld.setWeatherParameters(6000, 0, false, false);
        }
    }

    public static void reject(ServerPlayer target) {
        MinecraftServer server = target.server;
        Proposal pr = PENDING.remove(target.getUUID());
        if (pr == null || pr.expires() < now(server)) {
            say(target, "No tienes ninguna declaración pendiente.", ChatFormatting.RED);
            return;
        }
        ServerPlayer p = server.getPlayerList().getPlayer(pr.proposer());
        say(target, "Has rechazado la declaración de " + pr.proposerName() + ".", ChatFormatting.GRAY);
        if (p == null) {
            sadMoment(server, target, target);
            return;
        }
        say(p, name(target) + " ha rechazado tu declaración... Tu corazón se rompe.", ChatFormatting.DARK_PURPLE);
        title(p, "Corazón roto", ChatFormatting.DARK_PURPLE, name(target) + " ha rechazado tu amor");
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 600, 0));
        p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 600, 0));
        p.serverLevel().sendParticles(ParticleTypes.FALLING_WATER, p.getX(), p.getY() + 1.6, p.getZ(), 20, 0.3, 0.1, 0.3, 0.0);
        sadMoment(server, p, target);
    }

    /** Empieza a llover y suena la música triste para los implicados y quienes están cerca. */
    private static void sadMoment(MinecraftServer server, ServerPlayer a, ServerPlayer b) {
        server.overworld().setWeatherParameters(0, 6000, true, false);
        for (ServerPlayer sp : server.getPlayerList().getPlayers()) {
            boolean involved = sp == a || sp == b;
            boolean near = sp.level() == a.level() && sp.distanceTo(a) < 48.0F;
            if (involved || near) {
                sound(sp, ModSounds.SAD_MUSIC.get(), 1.0F, 1.0F);
            }
        }
    }

    private static void fireworks(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        for (int i = 0; i < 2; i++) {
            ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
            CompoundTag fw = rocket.getOrCreateTagElement("Fireworks");
            fw.putByte("Flight", (byte) 1);
            ListTag expl = new ListTag();
            CompoundTag e = new CompoundTag();
            e.putByte("Type", (byte) 1);
            e.putIntArray("Colors", new int[]{0xFF3B7F, 0xFFFFFF, 0xFF8FB8});
            e.putBoolean("Trail", true);
            e.putBoolean("Flicker", true);
            expl.add(e);
            fw.put("Explosions", expl);
            level.addFreshEntity(new FireworkRocketEntity(level, p.getX() + (i == 0 ? 1.5 : -1.5), p.getY(), p.getZ(), rocket));
        }
    }

    // ------------------------------------------------------------------ puntos y niveles

    private static void addPoints(MinecraftServer server, LoveData data, Couple c, int amount) {
        int before = c.level();
        c.points += amount;
        data.setDirty();
        int after = c.level();
        if (after > before) {
            for (UUID id : new UUID[]{c.a, c.b}) {
                ServerPlayer sp = server.getPlayerList().getPlayer(id);
                if (sp == null) continue;
                title(sp, "♥ Nivel de amor " + after + " ♥", ChatFormatting.LIGHT_PURPLE, PERKS[after - 1]);
                sound(sp, SoundEvents.PLAYER_LEVELUP, 1.0F, 1.2F);
                hearts(sp, 20);
            }
        }
    }

    /** Se llama cada 5 segundos para cada jugador. */
    public static void tickPlayer(ServerPlayer p) {
        MinecraftServer server = p.server;
        LoveData data = LoveData.get(server);
        Couple c = data.getCouple(p.getUUID());
        if (c == null) return;
        ServerPlayer partner = onlinePartner(p, c);
        if (partner == null) return;

        if (p.getUUID().equals(c.a)) {
            checkAnniversary(server, data, c, p, partner);
        }
        if (partner.level() != p.level() || partner.distanceTo(p) > NEAR_DISTANCE) return;

        if (p.getUUID().equals(c.a)) {
            addPoints(server, data, c, 1);
        }
        int lvl = c.level();
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 140, 0, true, false, true));
        if (lvl >= 2) p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 140, 0, true, false, true));
        if (lvl >= 3) p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 140, 0, true, false, true));
        if (lvl >= 4) p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 140, 0, true, false, true));
        if (lvl >= 5) p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 140, 0, true, false, true));
        hearts(p, 1);
    }

    /** Cada semana del juego (7 días) juntos, regalo de aniversario si los dos están conectados. */
    private static void checkAnniversary(MinecraftServer server, LoveData data, Couple c, ServerPlayer p, ServerPlayer partner) {
        int weeks = (int) ((now(server) - c.since) / 168000L);
        if (weeks <= c.lastAnniversary) return;
        c.lastAnniversary = weeks;
        data.setDirty();
        for (ServerPlayer sp : new ServerPlayer[]{p, partner}) {
            giveItem(sp, new ItemStack(ModItems.LOVE_CHOCOLATE.get(), 3));
            giveItem(sp, new ItemStack(ModItems.LOVE_ROSE.get(), 1));
            fireworks(sp);
            hearts(sp, 25);
            sound(sp, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.2F);
            title(sp, "♥ ¡Aniversario! ♥", ChatFormatting.LIGHT_PURPLE,
                    weeks + (weeks == 1 ? " semana" : " semanas") + " compartiendo destino");
            say(sp, "Regalo de aniversario: 3 bombones y una rosa ♥", ChatFormatting.LIGHT_PURPLE);
        }
        addPoints(server, data, c, 20);
    }

    /** Cada 10 ticks: con la Alianza en la mano, la barra de acción señala hacia tu pareja. */
    public static void compass(ServerPlayer p) {
        if (!p.getMainHandItem().is(ModItems.BOND_RING.get()) && !p.getOffhandItem().is(ModItems.BOND_RING.get())) return;
        Couple c = couple(p);
        if (c == null) return;
        ServerPlayer partner = onlinePartner(p, c);
        if (partner == null) {
            bar(p, "♥ " + c.otherName(p.getUUID()) + " no está conectado", ChatFormatting.GRAY);
            return;
        }
        if (partner.level() != p.level()) {
            bar(p, "♥ " + name(partner) + " está en otra dimensión (" + partner.level().dimension().location() + ")", ChatFormatting.LIGHT_PURPLE);
            return;
        }
        double dx = partner.getX() - p.getX();
        double dz = partner.getZ() - p.getZ();
        double target = Math.toDegrees(Math.atan2(-dx, dz));
        double diff = Mth.wrapDegrees(target - p.getYRot());
        String[] arrows = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};
        int idx = Math.floorMod((int) Math.round(diff / 45.0), 8);
        bar(p, "♥ " + name(partner) + "  " + arrows[idx] + "  " + (int) partner.distanceTo(p) + " bloques", ChatFormatting.LIGHT_PURPLE);
    }

    /** Beso: los dos cerca, con corazones, regeneración y puntos de amor. */
    public static void kiss(ServerPlayer p) {
        Couple c = requireCouple(p);
        if (c == null) return;
        ServerPlayer partner = requirePartnerOnline(p, c);
        if (partner == null) return;
        if (partner.level() != p.level() || partner.distanceTo(p) > 3.0F) {
            say(p, "Tenéis que estar a menos de 3 bloques el uno del otro.", ChatFormatting.RED);
            return;
        }
        MinecraftServer server = p.server;
        long now = now(server);
        Long cd = PING_COOLDOWN.get(p.getUUID());
        if (cd != null && cd > now) return;
        PING_COOLDOWN.put(p.getUUID(), now + 600L);
        for (ServerPlayer sp : new ServerPlayer[]{p, partner}) {
            hearts(sp, 25);
            sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            sound(sp, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.8F);
            bar(sp, "♥ Un beso entre " + name(p) + " y " + name(partner) + " ♥", ChatFormatting.LIGHT_PURPLE);
        }
        addPoints(server, LoveData.get(server), c, 5);
    }

    /** Si tu pareja cae, sientes un vacío: música triste y un rato de lentitud (sin lluvia). */
    public static void onPartnerLost(ServerPlayer dead) {
        Couple c = couple(dead);
        if (c == null) return;
        ServerPlayer partner = onlinePartner(dead, c);
        if (partner == null) return;
        say(partner, "Sientes un vacío en el pecho: " + name(dead) + " ha caído...", ChatFormatting.DARK_PURPLE);
        sound(partner, ModSounds.SAD_MUSIC.get(), 1.0F, 1.0F);
        partner.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 0));
    }

    /** Si no tienes cama y vuestro hogar compartido existe, reapareces allí. */
    public static void onRespawn(ServerPlayer p) {
        Couple c = couple(p);
        if (c == null || !c.hasHome || p.getRespawnPosition() != null) return;
        ServerLevel level = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(c.homeDim)));
        if (level == null) return;
        p.teleportTo(level, c.hx, c.hy, c.hz, c.hyaw, 0.0F);
        bar(p, "♥ Reapareces en vuestro hogar compartido", ChatFormatting.LIGHT_PURPLE);
    }

    // ------------------------------------------------------------------ amor que salva

    public static boolean tryRevive(ServerPlayer p, DamageSource source) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return false;
        MinecraftServer server = p.server;
        LoveData data = LoveData.get(server);
        Couple c = data.getCouple(p.getUUID());
        if (c == null || c.level() < 3) return false;
        ServerPlayer partner = onlinePartner(p, c);
        if (partner == null) return false;
        long now = now(server);
        Long cd = REVIVE_COOLDOWN.get(p.getUUID());
        if (cd != null && cd > now) return false;
        REVIVE_COOLDOWN.put(p.getUUID(), now + REVIVE_COOLDOWN_TICKS);

        p.setHealth(6.0F);
        p.removeAllEffects();
        p.clearFire();
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 1));
        p.level().broadcastEntityEvent(p, (byte) 35);
        title(p, "♥ Amor que salva ♥", ChatFormatting.LIGHT_PURPLE, name(partner) + " te ha devuelto a la vida");
        say(partner, "Tu amor ha salvado a " + name(p) + ". Estás agotado por el esfuerzo...", ChatFormatting.LIGHT_PURPLE);
        partner.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 600, 0));
        hearts(p, 30);
        return true;
    }

    // ------------------------------------------------------------------ poderes de pareja

    public static void teleportToPartner(ServerPlayer p) {
        if (isViewing(p)) {
            say(p, "Primero vuelve a tus propios ojos (agáchate).", ChatFormatting.RED);
            return;
        }
        Couple c = requireCouple(p);
        if (c == null) return;
        ServerPlayer partner = requirePartnerOnline(p, c);
        if (partner == null) return;
        long now = now(p.server);
        Long cd = TP_COOLDOWN.get(p.getUUID());
        if (cd != null && cd > now) {
            say(p, "El amor necesita un respiro: espera " + ((cd - now) / 20 + 1) + " s.", ChatFormatting.RED);
            return;
        }
        TP_COOLDOWN.put(p.getUUID(), now + TP_COOLDOWN_TICKS);
        p.teleportTo(partner.serverLevel(), partner.getX(), partner.getY(), partner.getZ(), partner.getYRot(), partner.getXRot());
        p.fallDistance = 0.0F;
        sound(p, SoundEvents.ENDERMAN_TELEPORT, 1.0F, 1.2F);
        hearts(p, 15);
        hearts(partner, 15);
        bar(p, "♥ Te has reunido con " + name(partner), ChatFormatting.LIGHT_PURPLE);
        bar(partner, "♥ " + name(p) + " ha venido a tu lado", ChatFormatting.LIGHT_PURPLE);
    }

    public static void openPartnerInventory(ServerPlayer p) {
        Couple c = requireCouple(p);
        if (c == null) return;
        ServerPlayer partner = requirePartnerOnline(p, c);
        if (partner == null) return;
        PartnerInventory inv = new PartnerInventory(partner);
        MenuProvider provider = new SimpleMenuProvider(
                (id, playerInv, player) -> new ChestMenu(MenuType.GENERIC_9x5, id, playerInv, inv, 5),
                Component.literal("♥ Inventario de " + name(partner)));
        p.openMenu(provider);
        bar(partner, name(p) + " está mirando tu inventario ♥", ChatFormatting.LIGHT_PURPLE);
    }

    public static void openPartnerEnderChest(ServerPlayer p) {
        Couple c = requireCouple(p);
        if (c == null) return;
        ServerPlayer partner = requirePartnerOnline(p, c);
        if (partner == null) return;
        MenuProvider provider = new SimpleMenuProvider(
                (id, playerInv, player) -> ChestMenu.threeRows(id, playerInv, partner.getEnderChestInventory()),
                Component.literal("♥ Cofre de Ender de " + name(partner)));
        p.openMenu(provider);
        bar(partner, name(p) + " está mirando tu cofre de Ender ♥", ChatFormatting.LIGHT_PURPLE);
    }

    public static void setHome(ServerPlayer p) {
        if (isViewing(p)) {
            say(p, "Primero vuelve a tus propios ojos (agáchate).", ChatFormatting.RED);
            return;
        }
        Couple c = requireCouple(p);
        if (c == null) return;
        c.hasHome = true;
        c.homeDim = p.level().dimension().location().toString();
        c.hx = p.getX();
        c.hy = p.getY();
        c.hz = p.getZ();
        c.hyaw = p.getYRot();
        LoveData.get(p.server).setDirty();
        say(p, "♥ Hogar compartido guardado aquí. Los dos podéis volver con /amor hogar.", ChatFormatting.LIGHT_PURPLE);
        ServerPlayer partner = onlinePartner(p, c);
        if (partner != null) say(partner, name(p) + " ha guardado vuestro hogar compartido ♥", ChatFormatting.LIGHT_PURPLE);
    }

    public static void goHome(ServerPlayer p) {
        if (isViewing(p)) {
            say(p, "Primero vuelve a tus propios ojos (agáchate).", ChatFormatting.RED);
            return;
        }
        Couple c = requireCouple(p);
        if (c == null) return;
        if (!c.hasHome) {
            say(p, "Todavía no tenéis hogar compartido. Usa /amor sethogar.", ChatFormatting.RED);
            return;
        }
        ServerLevel level = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(c.homeDim)));
        if (level == null) {
            say(p, "No se encuentra la dimensión de vuestro hogar.", ChatFormatting.RED);
            return;
        }
        long now = now(p.server);
        Long cd = TP_COOLDOWN.get(p.getUUID());
        if (cd != null && cd > now) {
            say(p, "El amor necesita un respiro: espera " + ((cd - now) / 20 + 1) + " s.", ChatFormatting.RED);
            return;
        }
        TP_COOLDOWN.put(p.getUUID(), now + TP_COOLDOWN_TICKS);
        p.teleportTo(level, c.hx, c.hy, c.hz, c.hyaw, 0.0F);
        p.fallDistance = 0.0F;
        sound(p, SoundEvents.ENDERMAN_TELEPORT, 1.0F, 1.2F);
        bar(p, "♥ Bienvenido a casa", ChatFormatting.LIGHT_PURPLE);
    }

    public static void where(ServerPlayer p) {
        Couple c = requireCouple(p);
        if (c == null) return;
        ServerPlayer partner = requirePartnerOnline(p, c);
        if (partner == null) return;
        String dim = partner.level().dimension().location().toString();
        String text = name(partner) + " está en " + (int) partner.getX() + ", " + (int) partner.getY() + ", " + (int) partner.getZ() + " (" + dim + ")";
        if (partner.level() == p.level()) {
            text += " a " + (int) partner.distanceTo(p) + " bloques";
        }
        say(p, "♥ " + text, ChatFormatting.LIGHT_PURPLE);
    }

    public static void ping(ServerPlayer p) {
        Couple c = requireCouple(p);
        if (c == null) return;
        ServerPlayer partner = requirePartnerOnline(p, c);
        if (partner == null) return;
        long now = now(p.server);
        Long cd = PING_COOLDOWN.get(p.getUUID());
        if (cd != null && cd > now) return;
        PING_COOLDOWN.put(p.getUUID(), now + PING_COOLDOWN_TICKS);
        bar(partner, "♥ " + name(p) + " está pensando en ti ♥", ChatFormatting.LIGHT_PURPLE);
        sound(partner, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.5F);
        hearts(partner, 12);
        bar(p, "♥ Le has enviado un corazón a " + name(partner), ChatFormatting.LIGHT_PURPLE);
    }

    public static void whisper(ServerPlayer p, String message) {
        Couple c = requireCouple(p);
        if (c == null) return;
        ServerPlayer partner = requirePartnerOnline(p, c);
        if (partner == null) return;
        Component line = Component.literal("<♥ " + name(p) + "> " + message).withStyle(ChatFormatting.LIGHT_PURPLE);
        partner.sendSystemMessage(line);
        p.sendSystemMessage(line);
        sound(partner, SoundEvents.AMETHYST_BLOCK_CHIME, 0.7F, 1.8F);
    }

    public static void giveRose(ServerPlayer giver, ServerPlayer receiver) {
        MinecraftServer server = giver.server;
        hearts(receiver, 10);
        bar(receiver, name(giver) + " te regala una rosa ♥", ChatFormatting.LIGHT_PURPLE);
        bar(giver, "Le has regalado una rosa a " + name(receiver), ChatFormatting.LIGHT_PURPLE);
        LoveData data = LoveData.get(server);
        Couple c = data.getCouple(giver.getUUID());
        if (c != null && c.has(receiver.getUUID())) {
            receiver.heal(4.0F);
            long now = now(server);
            Long cd = ROSE_COOLDOWN.get(giver.getUUID());
            if (cd == null || cd <= now) {
                ROSE_COOLDOWN.put(giver.getUUID(), now + ROSE_COOLDOWN_TICKS);
                addPoints(server, data, c, 10);
            }
        }
    }

    // ------------------------------------------------------------------ Ojo del Amor

    public static boolean isViewing(ServerPlayer p) {
        return VIEWS.containsKey(p.getUUID());
    }

    /** Empieza a ver a través de los ojos de la pareja (modo espectador temporal + cámara). */
    public static void startView(ServerPlayer p) {
        Couple c = requireCouple(p);
        if (c == null) return;
        ServerPlayer partner = requirePartnerOnline(p, c);
        if (partner == null) return;
        if (isViewing(p)) {
            say(p, "Ya estás mirando a través de sus ojos. Agáchate para salir.", ChatFormatting.RED);
            return;
        }
        if (p.isSpectator()) {
            say(p, "No puedes usar el Ojo del Amor en modo espectador.", ChatFormatting.RED);
            return;
        }
        if (c.isPrivate(partner.getUUID())) {
            say(p, name(partner) + " prefiere no ser observado ahora mismo.", ChatFormatting.RED);
            return;
        }
        long now = now(p.server);
        Long cd = VIEW_COOLDOWN.get(p.getUUID());
        if (cd != null && cd > now) {
            say(p, "Tus ojos necesitan descansar: espera " + ((cd - now) / 20 + 1) + " s.", ChatFormatting.RED);
            return;
        }
        if (p.isPassenger()) p.stopRiding();

        CompoundTag tag = new CompoundTag();
        tag.putString("dim", p.level().dimension().location().toString());
        tag.putDouble("x", p.getX());
        tag.putDouble("y", p.getY());
        tag.putDouble("z", p.getZ());
        tag.putFloat("yaw", p.getYRot());
        tag.putFloat("pitch", p.getXRot());
        tag.putInt("mode", p.gameMode.getGameModeForPlayer().getId());
        p.getPersistentData().put(VIEW_KEY, tag);
        VIEWS.put(p.getUUID(), new ViewSession(now + VIEW_TICKS));

        p.setGameMode(GameType.SPECTATOR);
        p.teleportTo(partner.serverLevel(), partner.getX(), partner.getY(), partner.getZ(), partner.getYRot(), partner.getXRot());
        p.setCamera(partner);

        say(p, "♥ Estás viendo a través de los ojos de " + name(partner) + ". Agáchate para volver.", ChatFormatting.LIGHT_PURPLE);
        bar(partner, name(p) + " está mirando a través de tus ojos ♥", ChatFormatting.LIGHT_PURPLE);
        sound(partner, SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 1.6F);
    }

    /** Termina la visión y devuelve al jugador a su sitio y su modo de juego. */
    public static void endView(ServerPlayer p, boolean notify) {
        boolean wasViewing = VIEWS.remove(p.getUUID()) != null;
        boolean hasTag = p.getPersistentData().contains(VIEW_KEY);
        CompoundTag tag = p.getPersistentData().getCompound(VIEW_KEY);
        p.getPersistentData().remove(VIEW_KEY);
        if (p.getCamera() != p) p.setCamera(p);
        if (hasTag) {
            ServerLevel level = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(tag.getString("dim"))));
            if (level != null) {
                p.teleportTo(level, tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z"), tag.getFloat("yaw"), tag.getFloat("pitch"));
            }
            p.setGameMode(GameType.byId(tag.getInt("mode")));
            p.fallDistance = 0.0F;
        } else if (wasViewing && p.isSpectator()) {
            p.setGameMode(GameType.SURVIVAL);
        }
        if (wasViewing || hasTag) {
            VIEW_COOLDOWN.put(p.getUUID(), now(p.server) + VIEW_COOLDOWN_TICKS);
            if (notify) bar(p, "♥ Has vuelto a tus propios ojos", ChatFormatting.LIGHT_PURPLE);
        }
    }

    /** Se llama cada 5 ticks: comprueba si hay que terminar la visión. */
    public static void tickView(ServerPlayer p) {
        ViewSession session = VIEWS.get(p.getUUID());
        if (session == null) return;
        MinecraftServer server = p.server;
        long now = now(server);
        Couple c = couple(p);
        ServerPlayer partner = c == null ? null : onlinePartner(p, c);
        if (c == null || partner == null || partner.isRemoved() || !partner.isAlive()) {
            endView(p, true);
            say(p, "La visión se ha desvanecido.", ChatFormatting.GRAY);
            return;
        }
        if (c.isPrivate(partner.getUUID())) {
            endView(p, true);
            say(p, name(partner) + " ha activado el modo privado.", ChatFormatting.GRAY);
            return;
        }
        if (p.getCamera() == p) {   // se ha agachado
            endView(p, true);
            return;
        }
        if (partner.level() != p.level()) {
            endView(p, true);
            say(p, name(partner) + " ha cambiado de dimensión y la visión se ha roto.", ChatFormatting.GRAY);
            return;
        }
        if (now >= session.endTick()) {
            endView(p, true);
            say(p, "Se acabó el tiempo de la visión.", ChatFormatting.GRAY);
            return;
        }
        if (p.tickCount % 20 == 0) {
            long secs = (session.endTick() - now) / 20;
            bar(p, "♥ Viendo con los ojos de " + name(partner) + " — agáchate para salir (" + secs + " s)", ChatFormatting.LIGHT_PURPLE);
            bar(partner, "♥ " + name(p) + " está viendo lo que ves", ChatFormatting.LIGHT_PURPLE);
        }
    }

    public static void endAllViews(MinecraftServer server) {
        for (ServerPlayer sp : server.getPlayerList().getPlayers()) {
            if (isViewing(sp) || sp.getPersistentData().contains(VIEW_KEY)) endView(sp, false);
        }
    }

    /** Activa o desactiva que tu pareja pueda mirar a través de tus ojos. */
    public static void togglePrivacy(ServerPlayer p) {
        Couple c = requireCouple(p);
        if (c == null) return;
        boolean now = !c.isPrivate(p.getUUID());
        c.setPrivate(p.getUUID(), now);
        LoveData.get(p.server).setDirty();
        say(p, now ? "Modo privado activado: tu pareja ya no puede mirar a través de tus ojos."
                   : "Modo privado desactivado: tu pareja puede usar el Ojo del Amor contigo.", ChatFormatting.LIGHT_PURPLE);
    }

    // ------------------------------------------------------------------ estado, ayuda, divorcio

    public static void status(ServerPlayer p) {
        Couple c = requireCouple(p);
        if (c == null) return;
        MinecraftServer server = p.server;
        long days = (now(server) - c.since) / 24000L;
        int lvl = c.level();
        boolean online = onlinePartner(p, c) != null;
        say(p, "♥ Pareja: " + c.otherName(p.getUUID()) + (online ? " (conectado)" : " (desconectado)"), ChatFormatting.LIGHT_PURPLE);
        say(p, "Días juntos: " + days, ChatFormatting.LIGHT_PURPLE);
        int next = c.nextLevelPoints();
        say(p, "Nivel de amor: " + lvl + " (" + c.points + (next < 0 ? " puntos, nivel máximo" : "/" + next + " puntos") + ")", ChatFormatting.LIGHT_PURPLE);
        say(p, "Beneficios actuales:", ChatFormatting.GRAY);
        for (int i = 0; i < lvl; i++) say(p, " • " + PERKS[i], ChatFormatting.WHITE);
        if (next >= 0) say(p, "Se consiguen puntos pasando tiempo cerca de tu pareja y regalándole rosas.", ChatFormatting.GRAY);
    }

    public static void help(ServerPlayer p) {
        String[] lines = {
                "♥ Amor Verdadero — comandos",
                "/amor proponer <jugador>  — declarar tu amor (necesitas un anillo)",
                "/amor aceptar | rechazar  — responder a una declaración",
                "/amor estado  — días juntos, nivel de amor y beneficios",
                "/amor tp  — ir junto a tu pareja (o click derecho con la Alianza)",
                "/amor inventario  — ver y usar su inventario (o agachado + click con la Alianza)",
                "/amor enderchest  — ver y usar su cofre de Ender",
                "/amor sethogar | hogar  — hogar compartido (reapareces allí si no tienes cama)",
                "Con la Alianza en la mano, la barra de acción te señala hacia tu pareja.",
                "/amor donde  — coordenadas de tu pareja",
                "/amor corazon  — enviarle un corazón",
                "/amor beso  — besar a tu pareja (a menos de 3 bloques)",
                "/amor ver  — mirar 30 s a través de sus ojos (o click derecho con el Ojo del Amor)",
                "/amor privacidad  — permitir o bloquear que tu pareja mire a través de tus ojos",
                "/amor decir <mensaje>  — mensaje privado a tu pareja",
                "/amor divorcio  — romper el vínculo"
        };
        for (String l : lines) say(p, l, ChatFormatting.LIGHT_PURPLE);
    }

    public static void divorce(ServerPlayer p, boolean confirmed) {
        MinecraftServer server = p.server;
        LoveData data = LoveData.get(server);
        Couple c = data.getCouple(p.getUUID());
        if (c == null) {
            say(p, "No tienes pareja.", ChatFormatting.RED);
            return;
        }
        long now = now(server);
        if (!confirmed) {
            DIVORCE_CONFIRM.put(p.getUUID(), now + 600L);
            MutableComponent btn = Component.literal("[ Confirmar divorcio ]").withStyle(Style.EMPTY
                    .withColor(ChatFormatting.RED).withBold(true)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/amor divorcio confirmar")));
            say(p, "¿Seguro que quieres romper el vínculo con " + c.otherName(p.getUUID()) + "? Esto no se puede deshacer.", ChatFormatting.RED);
            p.sendSystemMessage(btn);
            return;
        }
        Long until = DIVORCE_CONFIRM.get(p.getUUID());
        if (until == null || until < now) {
            say(p, "Primero usa /amor divorcio y confirma en menos de 30 segundos.", ChatFormatting.RED);
            return;
        }
        DIVORCE_CONFIRM.remove(p.getUUID());
        ServerPlayer partner = onlinePartner(p, c);
        data.remove(c);
        say(p, "El vínculo se ha roto. Las alianzas pierden su magia...", ChatFormatting.DARK_PURPLE);
        if (partner != null) {
            say(partner, name(p) + " ha roto el vínculo. Las alianzas pierden su magia...", ChatFormatting.DARK_PURPLE);
            title(partner, "Corazón roto", ChatFormatting.DARK_PURPLE, "El vínculo se ha roto");
            sadMoment(server, p, partner);
        } else {
            sadMoment(server, p, p);
        }
    }

    // ------------------------------------------------------------------ eventos de sesión

    public static void onLogin(ServerPlayer p) {
        if (p.getPersistentData().contains(VIEW_KEY)) endView(p, false);
        LoveData data = LoveData.get(p.server);
        Couple c = data.getCouple(p.getUUID());
        if (c == null) return;
        c.setName(p.getUUID(), name(p));
        data.setDirty();
        ServerPlayer partner = onlinePartner(p, c);
        if (partner != null) {
            bar(partner, "♥ " + name(p) + " se ha conectado", ChatFormatting.LIGHT_PURPLE);
            bar(p, "♥ " + name(partner) + " está conectado", ChatFormatting.LIGHT_PURPLE);
        }
    }

    public static void onLogout(ServerPlayer p) {
        if (isViewing(p) || p.getPersistentData().contains(VIEW_KEY)) endView(p, false);
        UUID id = p.getUUID();
        PENDING.remove(id);
        PENDING.values().removeIf(pr -> pr.proposer().equals(id));
    }

    public static void clearAll() {
        PENDING.clear();
        TP_COOLDOWN.clear();
        REVIVE_COOLDOWN.clear();
        ROSE_COOLDOWN.clear();
        PING_COOLDOWN.clear();
        DIVORCE_CONFIRM.clear();
        VIEWS.clear();
        VIEW_COOLDOWN.clear();
    }
}
