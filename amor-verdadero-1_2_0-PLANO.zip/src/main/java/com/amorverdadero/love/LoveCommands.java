package com.amorverdadero.love;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;

public final class LoveCommands {
    private LoveCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("amor")
                .executes(c -> {
                    LoveManager.help(c.getSource().getPlayerOrException());
                    return 1;
                })
                .then(Commands.literal("proponer")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(c -> {
                                    LoveManager.proposeFromInventory(c.getSource().getPlayerOrException(),
                                            EntityArgument.getPlayer(c, "jugador"));
                                    return 1;
                                })))
                .then(Commands.literal("aceptar").executes(c -> {
                    LoveManager.accept(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("rechazar").executes(c -> {
                    LoveManager.reject(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("estado").executes(c -> {
                    LoveManager.status(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("tp").executes(c -> {
                    LoveManager.teleportToPartner(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("inventario").executes(c -> {
                    LoveManager.openPartnerInventory(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("enderchest").executes(c -> {
                    LoveManager.openPartnerEnderChest(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("sethogar").executes(c -> {
                    LoveManager.setHome(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("hogar").executes(c -> {
                    LoveManager.goHome(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("donde").executes(c -> {
                    LoveManager.where(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("corazon").executes(c -> {
                    LoveManager.ping(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("beso").executes(c -> {
                    LoveManager.kiss(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("ver").executes(c -> {
                    LoveManager.startView(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("privacidad").executes(c -> {
                    LoveManager.togglePrivacy(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("decir")
                        .then(Commands.argument("mensaje", StringArgumentType.greedyString())
                                .executes(c -> {
                                    LoveManager.whisper(c.getSource().getPlayerOrException(),
                                            StringArgumentType.getString(c, "mensaje"));
                                    return 1;
                                })))
                .then(Commands.literal("divorcio")
                        .executes(c -> {
                            LoveManager.divorce(c.getSource().getPlayerOrException(), false);
                            return 1;
                        })
                        .then(Commands.literal("confirmar").executes(c -> {
                            LoveManager.divorce(c.getSource().getPlayerOrException(), true);
                            return 1;
                        }))));
    }
}
