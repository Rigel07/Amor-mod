package com.amorverdadero.item;

import com.amorverdadero.love.LoveManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Anillo de compromiso. tier 0 = oro, 1 = esmeralda, 2 = diamante. */
public class ProposalRingItem extends Item {
    private final int tier;

    public ProposalRingItem(Properties properties, int tier) {
        super(properties);
        this.tier = tier;
    }

    public int getTier() {
        return tier;
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof Player)) return InteractionResult.PASS;
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp && target instanceof ServerPlayer tp) {
            LoveManager.propose(sp, tp, tier);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Click derecho a otro jugador para declararle tu amor").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.literal("(o usa /amor proponer <jugador>)").withStyle(ChatFormatting.GRAY));
        if (tier == 1) {
            tooltip.add(Component.literal("Un amor que empieza con ventaja (+50 puntos de amor)").withStyle(ChatFormatting.GREEN));
        } else if (tier == 2) {
            tooltip.add(Component.literal("Un amor que empieza con ventaja (+150 puntos de amor)").withStyle(ChatFormatting.AQUA));
        } else if (tier == 3) {
            tooltip.add(Component.literal("Un amor legendario (+300 puntos de amor)").withStyle(ChatFormatting.LIGHT_PURPLE));
        }
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
