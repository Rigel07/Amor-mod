package com.amorverdadero.item;

import com.amorverdadero.love.LoveManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Alianza: click derecho = teletransporte a tu pareja; agachado + click derecho = ver su inventario. */
public class BondRingItem extends Item {
    public BondRingItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        if (player instanceof ServerPlayer sp) {
            if (sp.isShiftKeyDown()) {
                LoveManager.openPartnerInventory(sp);
            } else {
                LoveManager.teleportToPartner(sp);
            }
        }
        return InteractionResultHolder.success(stack);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Click derecho: ir junto a tu pareja").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.literal("Agachado + click derecho: ver su inventario").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.literal("Más comandos: /amor").withStyle(ChatFormatting.GRAY));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
