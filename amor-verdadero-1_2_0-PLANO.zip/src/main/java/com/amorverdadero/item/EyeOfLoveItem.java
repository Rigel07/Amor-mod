package com.amorverdadero.item;

import com.amorverdadero.love.LoveManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Ojo del Amor: click derecho para ver durante 30 s a través de los ojos de tu pareja. */
public class EyeOfLoveItem extends Item {
    public EyeOfLoveItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        if (player instanceof ServerPlayer sp) {
            LoveManager.startView(sp);
        }
        return InteractionResultHolder.success(stack);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Click derecho: mira durante 30 s lo que ve tu pareja").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.literal("Agáchate para volver a tus ojos").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Tu pareja puede bloquearlo con /amor privacidad").withStyle(ChatFormatting.GRAY));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
