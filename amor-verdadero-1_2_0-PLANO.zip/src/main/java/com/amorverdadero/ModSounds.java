package com.amorverdadero;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, AmorVerdadero.MODID);

    public static final RegistryObject<SoundEvent> LOVE_MUSIC = SOUNDS.register("love_music",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AmorVerdadero.MODID, "love_music")));

    public static final RegistryObject<SoundEvent> SAD_MUSIC = SOUNDS.register("sad_music",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AmorVerdadero.MODID, "sad_music")));
}
