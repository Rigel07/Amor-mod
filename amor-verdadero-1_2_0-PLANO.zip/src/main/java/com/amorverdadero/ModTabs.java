package com.amorverdadero;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AmorVerdadero.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("amor",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.amorverdadero"))
                    .icon(() -> new ItemStack(ModItems.DIAMOND_RING.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.GOLD_RING.get());
                        output.accept(ModItems.EMERALD_RING.get());
                        output.accept(ModItems.DIAMOND_RING.get());
                        output.accept(ModItems.NETHERITE_RING.get());
                        output.accept(ModItems.BOND_RING.get());
                        output.accept(ModItems.EYE_OF_LOVE.get());
                        output.accept(ModItems.LOVE_ROSE.get());
                        output.accept(ModItems.LOVE_CHOCOLATE.get());
                    })
                    .build());
}
