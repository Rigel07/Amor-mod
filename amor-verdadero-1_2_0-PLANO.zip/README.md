# Amor Verdadero 1.2.0 (Forge 1.20.1)

Mod del amor: anillos, declaraciones, parejas que comparten destino.

## Cómo se juega
1. Craftea un anillo (Oro: 4 lingotes de oro en forma de anillo; Esmeralda/Diamante: anillo de oro + esmeralda/diamante).
2. Click derecho con el anillo sobre otro jugador (o `/amor proponer <jugador>`).
3. La otra persona recibe un aviso con botones [Aceptar] / [Rechazar].
   - Rechaza: empieza a llover y suena música triste; quien se declaró queda con el corazón roto.
   - Acepta: fuegos artificiales, cada uno recibe una Alianza de Amor y comparten destino.

## Pareja
- Alianza: click derecho = ir junto a tu pareja; agachado + click derecho = ver/usar su inventario.
- `/amor inventario`, `/amor enderchest`, `/amor tp`, `/amor sethogar`, `/amor hogar`, `/amor donde`, `/amor corazon`, `/amor decir <mensaje>`, `/amor estado`, `/amor divorcio`.
- Nivel de amor (sube pasando tiempo cerca y regalando Rosas del Amor): regeneración, velocidad, absorción, fuerza, resistencia y "Amor que salva" (revive una vez cada 10 min).
- Rosa del Amor y Bombón de Amor: regalos/comida con efectos.

## Novedades 1.1.0
- Anillo de Netherita (anillo de oro + lingote de netherita): el amor empieza en nivel 3.
- Música alegre al aceptar una declaración.
- Brújula del amor: con la Alianza en la mano, la barra de acción señala hacia tu pareja y marca la distancia.
- `/amor beso` (a menos de 3 bloques): corazones, regeneración y puntos de amor.
- Regalo de aniversario cada 7 días del juego juntos (3 bombones y una rosa, si los dos están conectados).
- Si tu pareja muere, sientes un vacío (música triste y lentitud); sin lluvia.
- Si no tienes cama, reapareces en el hogar compartido.

## Novedades 1.2.0
- **Ojo del Amor** (ojo de Ender + lingote de oro + tinte rojo): click derecho (o `/amor ver`) para ver 30 s a través de los ojos de tu pareja. Agáchate para volver; vuelves exactamente a donde estabas y con tu modo de juego. Espera de 60 s entre usos.
- Tu pareja recibe un aviso mientras la miras y puede bloquearlo con `/amor privacidad`.
